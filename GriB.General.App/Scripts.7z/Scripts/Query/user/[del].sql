﻿update [pos_user] 
set [d] = @id
where [id] = @id